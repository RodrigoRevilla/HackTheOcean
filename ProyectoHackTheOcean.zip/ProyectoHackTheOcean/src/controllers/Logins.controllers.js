import { get } from "express/lib/response";
import { getConnection, sql, queries } from "../database"



export const getLogins = async (req, res) => {
  try {
    const pool = await getConnection();
    const result = await pool.request().query(queries.getAllLogins);
    res.json (result.recordset);
  } catch (error){
      res.status(500)
      res.send(error.message)
  }
}

export const createNewLogin = async (req, res) => {

    const {Nombre, Apellidos, Telefono, Correo, Contraseña} = req.body

if (Nombre == null || Apellidos == null || Telefono == null || Correo == null || Contraseña == null){
    return res.status (400).json({msg: "Solicitud incorrecta, llena todos los campos"})
}

try {
    const pool = await getConnection();
    
    await pool.request()
    .input("Nombre", sql.VarChar, Nombre)
    .input("Apellidos", sql.VarChar, Apellidos)
    .input("Telefono", sql.Int, Telefono)
    .input("Correo", sql.VarChar, Correo)
    .input("Contraseña", sql.VarChar, Contraseña)
    .query(queries.createNewLogin)

    res.json({Nombre, Apellidos, Telefono, Correo, Contraseña});
} catch (error) {
    res.status (500)
    res.send(error.message)
}
};

export const getLoginById = async (req, res) => {
    const { id } = req.params;

    const pool = await getConnection()
    const result = await pool.request()
    .input('Id', id).query(queries.getLoginById)

    res.send(result.recordset[0])
}

export const deleteLoginById = async (req, res) => {
    const { id } = req.params;

    const pool = await getConnection();
    const result = await pool
    .request()
    .input("Id", id)
    .query(queries.deleteLoginById)

    res.sendStatus(204);
};

export const getTotalLogins = async (req, res) => {
    const pool = await getConnection();
    const result = await pool
    .request()
    .query(queries.getTotalLogins);

    res.json(result.recordset[0][''])
};


export const updateLoginById = async (req,res) => {

    const {Nombre, Apellidos, Telefono, Correo, Contraseña} = req.body;
    const { id } = req.params

    if ((Nombre == null || Apellidos == null || Telefono == null || Correo == null || Contraseña == null)) {
        return res.status (400).json({msg: "Solicitud incorrecta, llena todos los campos"})
    }

    const pool = await getConnection()
    await pool
    .request()
    .input('Nombre', sql.VarChar, Nombre)
    .input('Apellidos', sql.VarChar, Apellidos)
    .input('Telefono', sql.Int, Telefono)
    .input('Correo', sql.VarChar, Correo)
    .input('Contraseña', sql.VarChar, Contraseña)
    .input('id', sql.Int,id)
    .query(queries.updateLoginById);

    res.json({Nombre, Apellidos, Telefono, Correo, Contraseña});
};
import express from "express";
import config from "./config";

import LoginsRoutes from './routes/Logins.routes'

var cors = require ('cors')
const app = express()

//settings del puerto
app.set('port', config.port)
app.use (cors())

//middlewares
app.use(express.json())
app.use(express.urlencoded({extended: false}))

app.use(LoginsRoutes)

export default app
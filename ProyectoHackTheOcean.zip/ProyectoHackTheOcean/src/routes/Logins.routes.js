import {Router} from "express";
import { createNewLogin, getLogins, getLoginById, deleteLoginById, getTotalLogins, updateLoginById} from "../controllers/Logins.controllers";



const router = Router()

router.get ('/Logins', getLogins);

router.post ('/Logins', createNewLogin);

router.get ('/Logins/count', getTotalLogins);

router.get ('/Logins/:id', getLoginById);

router.delete ('/Logins/:id', deleteLoginById);

router.put ('/Logins/:id', updateLoginById);


export default router
import { createNewLogin, getLoginById, updateLoginById } from "../controllers/Logins.controllers";

export const queries = {
    getAllLogins: 'SELECT * FROM InicioSesion',
    createNewLogin: 'INSERT INTO InicioSesion (Nombre, Apellidos, Telefono, Correo, Contraseña) VALUES (@Nombre, @Apellidos, @Telefono, @Correo, @Contraseña)',
    getLoginById: 'SELECT * FROM InicioSesion Where Id = @Id',
    deleteLoginById: 'DELETE FROM [Logins].[dbo].[InicioSesion] WHERE Id = @Id',
    getTotalLogins: 'SELECT COUNT (*) FROM InicioSesion',
    updateLoginById: 'UPDATE InicioSesion SET Nombre = @Nombre, Apellidos = @Apellidos, Telefono = @Telefono, Correo = @Correo, Contraseña = @Contraseña WHERE Id = @Id'
}; 
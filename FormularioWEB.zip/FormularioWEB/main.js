const postsList = document.querySelector ('.posts-list')
const addPostForm = document.querySelector('.add-post-form')
const Nombrevalue = document.getElementById('Nombre-value')
const Apellidosvalue = document.getElementById('Apellidos-value')
const Telefonovalue = document.getElementById('Telefono-value')
const Correovalue = document.getElementById('Correo-value')
const Contraseñavalue = document.getElementById('Contraseña-value')
const btnSubmit = document.querySelector('.btn')
let output = '';

const renderPosts = (posts) => {
    posts.forEach (post => {
        output += `
        <div class="card mt-4 col-md-6 bg-light">
        <div class="card-body" data-id=${post.Id}>
          <h5 class="card-title">${post.Nombre}</h5>
          <h6 class="card-subtitle mb-2 text-muted">${post.Apellidos}</h6>
          <p class="card-text">${post.Telefono}</p>
          <p class="card-text2">${post.Correo}</p>
          <p class="card-text3">${post.Contraseña}</p>
          <a href="#" class="card-link" id="edit-post"> Editar </a>
          <a href="#" class="card-link" id="delete-post"> Borrar </a>
        </div>
      </div>
        `;
    });
    postsList.innerHTML = output;
}

const url = 'http://localhost:3000/Logins';

//Metodo get, obteniendo usuarios
fetch (url)
.then (res => res.json())
.then (data => renderPosts(data))


postsList.addEventListener('click', (e) => {
    e.preventDefault();
    let delButtonIsPressed = e.target.id == 'delete-post';
    let editButtonIsPressed = e.target.id == 'edit-post';

    let id = e.target.parentElement.dataset.id;


    //Metodo delete, eliminar registros

    if (delButtonIsPressed) {
        fetch(`${url}/${id}`, { 
            method: 'DELETE',
        })
        .then(res => res.json())
        location.reload
    }


    if(editButtonIsPressed){
        const parent = e.target.parentElement;
        let titleContent = parent.querySelector('.card-title').textContent;
        let bodyContent = parent.querySelector('.card-subtitle').textContent;
        let telefonoContent = parent.querySelector('.card-text').textContent;
        let correoContent = parent.querySelector('.card-text2').textContent;
        let contraseñaContent = parent.querySelector('.card-text3').textContent;


        Nombrevalue.value = titleContent;
        Apellidosvalue.value = bodyContent;
        Telefonovalue.value = telefonoContent;
        Correovalue.value = correoContent;
        Contraseñavalue.value = contraseñaContent;
    }
    
     //Actualizando login con el metodo UPDATE

      btnSubmit.addEventListener('click', (e) => {
          e.preventDefault()
          fetch(`${url}/${id}`, {
              method: 'PUT',
              headers: {
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                  Nombre: Nombrevalue.value,
                  Apellidos: Apellidosvalue.value,
                  Telefono: Telefonovalue.value,
                  Correo: Correovalue.value,
                  Contraseña : Contraseñavalue.value
              })
          })
      .then(res => res.json())
      location.reload()
 
    })
});

//Metodo POST crear nuevo usuario 
addPostForm.addEventListener('submit', (e) => {
    e.preventDefault();
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            Nombre: Nombrevalue.value,
            Apellidos: Apellidosvalue.value,
            Telefono: Telefonovalue.value,
            Correo: Correovalue.value,
            Contraseña: Contraseñavalue.value
        })
    })
    .then(res => res.json())
    .then(data => {
        const dataArr = [];
        dataArr.push(data);
        renderPosts(dataArr);
        location.reload()
    })

    //reseteando los campos 
    Nombrevalue.value = "";
    Apellidosvalue.value = "";
    Telefonovalue.value = "";
    Correovalue.value = "";
    Contraseñavalue.value = "";
})

